import{l as o,d as r}from"../chunks/BUb5hhcM.js";export{o as load_css,r as start};
