import{l as o,d as r}from"../chunks/CpB61uSw.js";export{o as load_css,r as start};
